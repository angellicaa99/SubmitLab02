package com.github.angellicaa99.submitlab02

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class activityLifeCycle: AppCompatActivity() {

    val TAG = "Main Activity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d(TAG, "In Oncreate")
        Toast.makeText(this, "You are under the Button", Toast.LENGTH_SHORT).show()
    }

    override fun onStart()
    {
        super.onStart()
        Toast.makeText(this, "Button is onStart", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnStart")
    }
    override fun onPause()
    {
        super.onPause()
        Toast.makeText(this, "Button is onPause", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnPause")
    }
    override fun onStop()
    {
        super.onStop()
        Toast.makeText(this, "App is onStop", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnStop")
    }
    override fun onDestroy()
    {
        super.onDestroy()
        Toast.makeText(this, "Button is onDestroy", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnDestroy")
    }
    override fun onResume() {
        super.onResume()
        Toast.makeText(this, "Button is onResume", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnResume")
    }
    override fun onRestart(){
        super.onRestart()
        Toast.makeText(this, "Button is onRestart", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnRestart")
    }

}