package com.github.angellicaa99.submitlab02

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    val TAG = "Main Activity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d(TAG, "In OnCreate")
        val activityButtons = findViewById(R.id.activityButton) as Button
        activityButtons.setOnClickListener { //mindahin data dari satu activity ke activity yang lain
            val i = Intent(this, activityLifeCycle::class.java)
            startActivity(i)

        }
    }
    override fun onStart()
    {
        super.onStart()
        Toast.makeText(this, "App is onStart", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnStart")
    }
    override fun onPause()
    {
        super.onPause()
        Toast.makeText(this, "App is onPause", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnStart")
    }
    override fun onStop()
    {
        super.onStop()
        Toast.makeText(this, "App is onStop", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnStop")
    }
    override fun onDestroy()
    {
        super.onDestroy()
        Toast.makeText(this, "App is onDestroy", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnDestroy")
    }
    override fun onResume() {
        super.onResume()
        Toast.makeText(this, "App is onResume", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnResume")
    }
    override fun onRestart(){
        super.onRestart()
        Toast.makeText(this, "App is onRestart", Toast.LENGTH_SHORT).show()
        Log.d(TAG, "In OnRestart")
    }
}
